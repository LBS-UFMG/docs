# Modelo de tese/dissertação BIOINFO v1.0

Este projeto apresenta um modelo de dissertação ou tese para o Programa Interunidades de Pós-graduação em Bioinformática da UFMG. Faça as modificações que achar necessário. Comece alterando o arquivo "\_principal.tex".

Você pode copiar esse projeto no Overleaf pelo link: https://www.overleaf.com/read/hgnpzzjyrthz#42c515

**Autor:** Diego Mariano | www.diegomariano.com (baseado no modelo proposto por Lauro César Araujo em conformidade com as normas ABNT NBR 14724:2011)
